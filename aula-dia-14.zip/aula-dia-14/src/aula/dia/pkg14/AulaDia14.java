/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.dia.pkg14;

import javax.swing.JOptionPane;

/**
 *
 * @author joao.vscosta18
 */
public class AulaDia14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //String nome = JOptionPane.showInputDialog(null,"Digite seu Nome");
        //JOptionPane.showMessageDialog(null,"Ola, " + nome);
        double numero1 = Double.parseDouble (JOptionPane.showInputDialog(null,"Digite sua idade 1"));
        double numero2 = Double.parseDouble (JOptionPane.showInputDialog(null,"Digite sua idade 2"));
        double soma = numero1 + numero2 ;
        double multiplicar = numero1 * numero2 ;
        JOptionPane.showMessageDialog(null,"Resultado somando  = "+soma);
        JOptionPane.showMessageDialog(null,"Resultado multiplicando  = "+multiplicar);                                                   
    }
    
    
    
    
}
